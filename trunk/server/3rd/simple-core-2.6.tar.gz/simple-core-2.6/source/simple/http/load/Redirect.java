/*
 * Redirect.java March 2005
 *
 * Copyright (C) 2005, Niall Gallagher <niallg@users.sf.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General 
 * Public License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330, 
 * Boston, MA  02111-1307  USA
 */

package simple.http.load;

import simple.http.serve.Resource;
import simple.http.Response;
import simple.http.Request;

/**
 * The <code>Redirect</code> is used to perform some operations
 * before handing the transaction to another <code>Resource</code>.
 * Typically an implementation should not commit the response 
 * so that the resource it is redirected to can continue safely.
 * <p>
 * Two methods are provided, which will enable a suitable 
 * <code>Resource</code> to be located using either a resource
 * name or a target URI. The <code>lookup</code> method will
 * take a resource name or alias, and the <code>resolve</code>
 * method will translate a URI or path to acquire a resource.
 * 
 * @author Niall Gallagher
 */
public interface Redirect {

   /**
    * The <code>redirect</code> method is used to perform various
    * operations before a request or client is redirected. This is
    * useful when no specific view is associated with a target
    * service or resource. It allows delegation to other resources,
    * which can then render the view for the HTTP transaction.
    * 
    * @param req the HTTP request object representing the client
    * @param resp the HTTP response object to send a reply with
    * 
    * @return returns the resource used to handle the request
    *  
    * @throws Exception thrown if there is a problem processing 
    */ 
   public Resource redirect(Request req, Response resp) throws Exception;

   /**
    * This method is used to retrieve resources using the name 
    * for that resource. This will typically map directly to the
    * <code>LoaderEngine</code> object's <code>lookup</code>
    * method. If desired, extra functionality could be 
    * introduced to provide more useful names for resources.
    *
    * @param target the target name referencing the resource
    *
    * @return the <code>Resource</code> that has been located
    */
   public Resource lookup(String target) throws Exception;

   /**
    * This method is used to retrieve resources using a specific
    * URI. The URI format is not important, this method should
    * be able to handle absolute and realitive URI formats. The
    * following list of URI strings should be acceptable forms:
    * <pre>
    * 
    * http://www.domain.com/path?query
    * /path;param=value?query
    * /path/file
    *
    * </pre>
    * Like the <code>lookup</code> method this will typically
    * map directly to the <code>LoaderEngine</code> method for
    * resolving resources given a URI target. However, this 
    * will resolve any target URI given. Extra functionality
    * can be introduced to map URI strings to resources.
    *
    * @param target the URI string referencing the resource
    *
    * @return the <code>Resource</code> that has been located
    */  
   public Resource resolve(String target) throws Exception;
}
